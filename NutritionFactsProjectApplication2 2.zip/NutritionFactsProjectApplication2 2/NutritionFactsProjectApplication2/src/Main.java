import javax.swing.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

       Carbohydrates c1 = new Carbohydrates("g ", "25g ", "5g ", "g" );
       Calories c2 = new Calories("g", "1");
       Vitamins v1 = new Vitamins("healthy skin", "red blood cells", "immune system ",
               "blood coagulate normally ", "molecules ", "phosphorus");
       Potassium p2 = new Potassium("mg ", "1 medium");
       Protein p1 = new Protein("g", "4g", "6g", "8g",
               "5g", "10g", "5g", "4g", "8g");



        ArrayList<Micronutrients> micronutrientsList  = new ArrayList<>();
        micronutrientsList.add(v1);
        micronutrientsList.add(p2);


        for (Micronutrients micronutrients : micronutrientsList) {

            System.out.println(micronutrients);
        }


        ArrayList<Macronutrients> macronutrientsList =  new ArrayList<>();
        macronutrientsList.add(c2);
        macronutrientsList.add(c1);
        macronutrientsList.add(p1);


        for (Macronutrients macronutrients : macronutrientsList) {

            System.out.println(macronutrients);
        }


        ArrayList<Printable> printableObjects = new ArrayList<>();
        printableObjects.add(v1);
        printableObjects.add(p1);
        printableObjects.add(p2);
        printableObjects.add(c1);
        printableObjects.add(c2);


        for(Printable p: printableObjects){
            p.printSetup();
            p.print();
        }

        Macronutrients mymacronutrients = new Macronutrients();
        mymacronutrients.macronutrientsImport();


        Micronutrients mymicronutrients = new Micronutrients();
        mymicronutrients.micronutrientsImport();


        Vitamins myvitamins = new Vitamins();
        myvitamins.vitaminsImport();


        Potassium mypotassium =  new Potassium();
        mypotassium.potassiumImport();


        Calories mycalories = new Calories();
        mycalories.caloriesImport();

        Protein myprotein = new Protein();
        myprotein.proteinImport();


        Carbohydrates mycarbohydrates = new Carbohydrates();
        mycarbohydrates.CarbohydratesImport();



        TestHarness m1 = new TestHarness();

        Protein protein = new Protein();

        protein.proteinInput();
        System.out.println(protein);

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the amount of servings: ");
        int amountOfServings = scanner.nextInt();


        int totalProtein = protein.calculateTotalProtein(amountOfServings);

        System.out.println("Total protein: " + amountOfServings + " Serving: " + totalProtein );


    }


}
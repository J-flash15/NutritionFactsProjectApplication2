package models;

public interface Printable { // Printable interface

    void printSetup(); // printSetup method

    void print(); // print method

}

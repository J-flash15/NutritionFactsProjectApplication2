public class Micronutrients {

    protected String vitaminsA, vitaminsC,  vitaminsD,
            vitaminsE,  vitaminsK,  vitaminsB9;

     protected String totalPotassium, potassiumPerServing;


    public Micronutrients(String vitaminsA, String vitaminsC, String vitaminsD, String vitaminsB9, String vitaminsK, String vitaminsE, String totalPotassium, String potassiumPerServing) {
        this.vitaminsA = vitaminsA;
        this.vitaminsC = vitaminsC;
        this.vitaminsD = vitaminsD;
        this.vitaminsB9 = vitaminsB9;
        this.vitaminsK = vitaminsK;
        this.vitaminsE = vitaminsE;
        this.totalPotassium = totalPotassium;
        this.potassiumPerServing = potassiumPerServing;
    }

    public Micronutrients() {

        totalPotassium = "totalPotassium";
        potassiumPerServing = "potassiumPerServing";
        vitaminsA = "vitaminsA";
        vitaminsC = "vitaminsC";
        vitaminsD = "vitaminsD";
        vitaminsE = "vitaminsE";
        vitaminsK = "vitaminsK";
        vitaminsB9 = "vitaminsB9";

       
    }


    public Micronutrients(String string, int i, int j) {
        totalPotassium = "totalPotassium";
        potassiumPerServing = "potassiumPerServing";
        vitaminsA = "vitaminsA";
        vitaminsC = "vitaminsC";
        vitaminsD = "vitaminsD";
        vitaminsE = "vitaminsE";
        vitaminsK = "vitaminsK";
        vitaminsB9 = "vitaminsB9";

        
    }



    public void micronutrientsImport() {

        System.out.println("These nutrients are mostly vitamins and minerals, " +
                "and are usually measured in milligrams (mg) or micrograms (mcg)");

    }


    public String getVitaminsA() {
        return vitaminsA;
    }

    public void setVitaminsA(String vitaminsA) {
        this.vitaminsA = vitaminsA;
    }

    public String getVitaminsC() {
        return vitaminsC;
    }

    public String getVitaminsD() {
        return vitaminsD;
    }

    public String getVitaminsE() {
        return vitaminsE;
    }

    public String getVitaminsK() {
        return vitaminsK;
    }

    public String getVitaminsB9() {
        return vitaminsB9;
    }

    public void setVitaminsB9(String vitaminB9) {
        this.vitaminsB9 = vitaminB9;
    }

    public void setVitaminsK(String vitaminK) {
        this.vitaminsK = vitaminK;
    }

    public void setVitaminsE(String vitaminE) {
        this.vitaminsE = vitaminE;
    }

    public void setVitaminsD(String vitaminD) {
        this.vitaminsD = vitaminD;
    }

    public void setVitaminsC(String vitaminC) {
        this.vitaminsC = vitaminC;
    }

    public String getTotalPotassium() {
        return totalPotassium;
    }

    public void setTotalPotassium(String totalPotassium) {
        this.totalPotassium = totalPotassium;
    }

    public String getPotassiumPerServing() {
        return potassiumPerServing;
    }

    public void setPotassiumPerServing(String potassiumPerServing) {
        this.potassiumPerServing = potassiumPerServing;
    }


    @Override
    public String toString() {
        return "com.controllers.Micronutrients{" +
                ", totalPotassium='" + totalPotassium + '\'' +
                ", potassiumPerServing='" + potassiumPerServing + '\'' +
                '}';
    }

    public void forEach(Object o) {
    }

    public String size() {

        return size();
    }

    public void forEach() {
    }
}

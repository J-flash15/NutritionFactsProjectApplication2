public class Potassium extends Micronutrients implements Printable {

    private String totalPotassium, potassiumPerServing;

    private String hulkBanner;



    public Potassium(String totalPotassium, String potassiumPerServing) {
        super(totalPotassium, potassiumPerServing);
        this.totalPotassium = totalPotassium;
        this.potassiumPerServing = potassiumPerServing;
    }



    public Potassium() {

        totalPotassium = "totalPotassium";
        potassiumPerServing = "potassiumPerServing";

    }


    public void potassiumImport() {

        System.out.println("models.Potassium: is an essential mineral that helps " +
                "the body function properly in many ways, including");
    }



    public String getTotalPotassium() {
        return totalPotassium;
    }

    public void setTotalPotassium(String totalPotassium) {
        this.totalPotassium = totalPotassium;
    }

    public String getPotassiumPerServing() {
        return potassiumPerServing;
    }

    public void setPotassiumPerServing(String potassiumPerServing) {
        this.potassiumPerServing = potassiumPerServing;
    }



    @Override
    public String toString() {
        return "models.Potassium{" +
                "totalPotassium=" + totalPotassium +
                "potassiumPerServing=" + potassiumPerServing  +
                '}';
    }






    public void printSetup() {

       hulkBanner = "******************************** models.Potassium ********************************";
    }

    public void print() {

        System.out.println(hulkBanner);
        System.out.println(this.toString());
    }

}

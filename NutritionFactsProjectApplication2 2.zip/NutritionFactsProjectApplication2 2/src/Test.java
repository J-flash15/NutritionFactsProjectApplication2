public @interface Test {

}
